Projeto PostgreSQL

Instale o tabulate para visualizar os resultados das querys com o comando abaixo!

```console
pip install tabulate
```

Adicionalmente, configure a senha de usuário do user postgres para 123.

Por fim, adicione o arquivo da amazon-meta.txt na pasta data, pois atualmente em data existe um arquivo amazon-meta.txt porém com menos produtos.
